//聊天消息

import 'dart:convert';
import 'dart:math';
import 'dart:ui';

import 'package:common_base/common_base.dart';
import 'package:data_center/live_old/model/data_manager.dart';
import 'package:data_center/live_old/model/room_msg.dart';
import 'package:data_center/live_old/model/room_player.dart';
import 'package:data_center/live_old/utility/string.dart';
import 'package:flutter/material.dart';
import 'package:live/page/home/room/sliver_chat/vo/base_titlle.dart';

import 'base_text_link.dart';

class RoomMsgChat extends BaseTextLink {
  final RoomMsg roomMsg;

  RoomMsgChat(this.roomMsg) {}

  @override
  void initData() {
    maxWidth = 500.w;
    links = [];
    String content = roomMsg.getValue('content', null);

    // textContent=   roomMsg.getValue('text');
    Map<String, dynamic> data = jsonDecode(content);
    print(content);
    if (data.containsKey('text')) {
      textContent = data['text'];
    } else {
      textContent = '没有Text数据';
      //{text: ❤️❤️‍🔥❤️❤️‍🔥❤️❤️‍🔥观看直播有风险，血压太高请找医生看病拿药。❤️❤️‍🔥❤️❤️‍🔥❤️❤️‍🔥}
      //{broken_id: 1197670397, user_id: 1682034565, cp_type: 10, notice_type: 1, pay_amount: 5880, optcode: 20, cp_name: 极速轮盘, app_user_id: 1002321579}
      // {{用戶餛飩nice}}完成了粉丝团任务{{「观看直播2分钟」}}, user_nickname: 用戶餛飩nice, create_time: 1748852054, optcode: 30, podcast_id: 1197670397, user_id: 1593260760}

      if (data['optcode'] == 30) {
        textContent = content;
      } else {
        textContent = '没有Text数据';
      }




    }

    if (roomMsg.id! < 0) {
      ///系统消息
      // textContent = '系统消息';
      textContent = '独家主播福利,等你来解锁！尽情畅享私\n密时刻,体验无与伦比的乐趣！';


      addHeadImageArr(
        BaseTittle(
          titleLen: 3,
          url: 'https://zhaogongzi25.github.io/web001/img001.png',
          fontSize: baseStyle.fontSize!,
          roundBox: Rect.fromLTRB(-2, -2, -2, 4),
          label: "系统",
        ),
      );
    } else {
      ///普通消息
      RoomPlayer? player =
          dataMgr.findObj(TableNames.roomPlayer, roomMsg.userId) != null
              ? dataMgr.findObj(TableNames.roomPlayer, roomMsg.userId)
                  as RoomPlayer
              : null;
      if (player != null || roomMsg.userId == 1) {
        textContent = '${player!.nickname}:' + textContent!;

        links!.add({
          'text': player!.nickname,
          'onTap': () {},
          'color': const Color.fromARGB(255, 252, 185, 0),
        });

        addHeadImageArr(
          BaseTittle(
            titleLen: 3,
            url: 'https://zhaogongzi25.github.io/web001/rank_41_50.png',
            fontSize: baseStyle.fontSize!,
            roundBox: Rect.fromLTRB(-2, -2, -2, 4),
            label: "${player!.level}级",
          ),
        );
        if(player.id==roomMsg.userId){
           addHeadImageArr(
          BaseTittle(
            titleLen: 3,
            url: 'https://zhaogongzi25.github.io/web001/bg_146_60.png',
            fontSize: baseStyle.fontSize!,
            roundBox: Rect.fromLTRB(-2, -2, -2, 4),
            label: "房主",
          ),
        );

        }


      } else {
        ///内存里没有的对象，走
        // textContent = '内存里没有的对象';
        hide = true;
      }
    }
  }
}

